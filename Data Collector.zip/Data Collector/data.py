import tkinter as tk
from tkinter import ttk
import csv
import re


class Data:
    def __init__(self):
        self.name = tk.StringVar()
        self.email = tk.StringVar()
        self.social_media = tk.StringVar()
        self.username = tk.StringVar()

        self.create_file()

    def create_file(self):
        try:
            with open("data.csv", "x") as new_file:
                writer = csv.writer(new_file)
                writer.writerow(["Name", "Email", "Social Media", "Username"])
        except FileExistsError:
            pass

    def write_to_csv(self):
        with open("data.csv", "a") as file:
            writer = csv.writer(file)
            writer.writerow(
                [
                    self.name.get(),
                    self.email.get(),
                    self.social_media.get(),
                    self.username.get(),
                ]
            )


class DataApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Data Collection and Search App")

        self.tab_control = ttk.Notebook(self.master)

        self.data_tab = ttk.Frame(self.tab_control)
        self.search_tab = ttk.Frame(self.tab_control)
        submit_style = ttk.Style()
        submit_style.configure("Submit.TButton", foreground="black", background="blue")
        self.tab_control.add(self.data_tab, text="Data Collection")
        self.tab_control.add(self.search_tab, text="Search")

        self.tab_control.pack(expand=1, fill="both")

        # Data Collection Tab
        self.data_instance = Data()
        self.create_data_collection_tab()

        # Search Tab
        self.create_search_tab()

    def create_data_collection_tab(self):
        data_frame = ttk.LabelFrame(self.data_tab, text="Data Collection")

        ttk.Label(data_frame, text="Name:").grid(row=0, column=0, sticky=tk.W, pady=5)
        ttk.Entry(data_frame, textvariable=self.data_instance.name).grid(
            row=0, column=1, pady=5
        )

        ttk.Label(data_frame, text="Email:").grid(row=1, column=0, sticky=tk.W, pady=5)
        ttk.Entry(data_frame, textvariable=self.data_instance.email).grid(
            row=1, column=1, pady=5
        )

        ttk.Label(data_frame, text="Social Media:").grid(
            row=2, column=0, sticky=tk.W, pady=5
        )
        ttk.Entry(data_frame, textvariable=self.data_instance.social_media).grid(
            row=2, column=1, pady=5
        )

        ttk.Label(data_frame, text="Username:").grid(
            row=3, column=0, sticky=tk.W, pady=5
        )
        ttk.Entry(data_frame, textvariable=self.data_instance.username).grid(
            row=3, column=1, pady=5
        )

        # Create a style for the Submit button
        submit_style = ttk.Style()
        submit_style.configure("Submit.TButton", foreground="black", background="blue")

        ttk.Button(
            data_frame,
            text="Submit",
            command=self.submit_data,
            style="Submit.TButton",  # Set the style for the button
        ).grid(row=4, columnspan=2, pady=10)

        data_frame.pack(padx=10, pady=10)

    def create_search_tab(self):
        search_frame = ttk.LabelFrame(self.search_tab, text="Search")

        ttk.Label(search_frame, text="Search Type:").grid(row=0, column=0, pady=5)

        search_var = tk.StringVar()
        search_var.set("Name")

        search_type_combobox = ttk.Combobox(
            search_frame, textvariable=search_var, values=["Name", "Username"]
        )
        search_type_combobox.grid(row=0, column=1, pady=5)

        search_entry = ttk.Entry(search_frame)
        search_entry.grid(row=1, column=0, columnspan=2, pady=5)

        # Create a style for the Search button
        search_style = ttk.Style()
        search_style.configure("Search.TButton", foreground="black", background="blue")

        ttk.Button(
            search_frame,
            text="Search",
            command=lambda: self.search_data(search_var.get(), search_entry.get()),
            style="Search.TButton",  # Set the style for the button
        ).grid(row=2, column=0, columnspan=2, pady=10)

        self.search_result_label = ttk.Label(search_frame, text="")
        self.search_result_label.grid(row=3, column=0, columnspan=2, pady=5)

        search_frame.pack(padx=10, pady=10)

    def submit_data(self):
        self.data_instance.write_to_csv()
        # Clear entry fields after submission
        self.data_instance.name.set("")
        self.data_instance.email.set("")
        self.data_instance.social_media.set("")
        self.data_instance.username.set()

    def search_data(self, search_type, search_term):
        result_text = "Person not found"
        with open("data.csv") as file:
            reader = csv.reader(file)
            header = next(reader)  # Read the header

            for row in reader:
                if search_type == "Name" and search_term.lower() in row[0].lower():
                    result_text = f"Name: {row[0]}\nUsername: {row[-1]}\nSocial Media: {row[2]}\nEmail: {row[1]}"
                    break
                elif (
                    search_type == "Username" and search_term.lower() in row[-1].lower()
                ):
                    result_text = f"Name: {row[0]}\nUsername: {row[-1]}\nSocial Media: {row[2]}\nEmail: {row[1]}"
                    break

        self.search_result_label.config(text=result_text)


def main():
    root = tk.Tk()
    app = DataApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
